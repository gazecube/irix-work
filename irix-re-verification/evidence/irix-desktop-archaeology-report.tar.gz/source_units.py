import re, subprocess, csv, json
from pathlib import Path
from collections import Counter,defaultdict
ROOT=Path('/mnt/data/irix_batch/all'); OUT=Path('/mnt/data/irix_batch/report')
rows=[]; bylib={}
for p in sorted(ROOT.iterdir()):
    if not p.is_file(): continue
    q=subprocess.run(['readelf','--debug-dump=decodedline',str(p)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,errors='replace').stdout
    files=[]
    # Each compilation unit/source starts as "foo.c++:" followed by File name...
    for line in q.splitlines():
        s=line.strip()
        if s.endswith(':') and not s.startswith(('Contents of','File name')) and ' ' not in s[:-1]:
            name=s[:-1]
            if re.search(r'\.(?:c|C|cc|cpp|cxx|c\+\+|f|for|f77|f90|p|pas)$',name,re.I): files.append(name)
    files=list(dict.fromkeys(files))
    bylib[p.name]=files
    extc=Counter()
    for name in files:
        low=name.lower()
        if low.endswith(('.c++','.cc','.cpp','.cxx','.C'.lower())): extc['C++']+=1
        elif low.endswith('.c'): extc['C']+=1
        elif low.endswith(('.f','.for','.f77','.f90')): extc['Fortran']+=1
        elif low.endswith(('.p','.pas')): extc['Pascal']+=1
    for lang,n in extc.items(): rows.append((p.name,lang,n,';'.join(files)))

with (OUT/'source_units.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['library','language','source_unit_count','source_units']); w.writerows(rows)

md=['# Source Units Recovered from DWARF `.debug_line`','']
for lib,files in bylib.items():
    if not files: continue
    md.append(f'## `{lib}`')
    for x in files: md.append(f'- `{x}`')
    md.append('')
(OUT/'SOURCE_UNITS.md').write_text('\n'.join(md))

summary=Counter()
for lib,files in bylib.items():
    langs=set()
    for name in files:
        low=name.lower()
        if low.endswith(('.c++','.cc','.cpp','.cxx')): langs.add('C++')
        elif low.endswith('.c'): langs.add('C')
        elif low.endswith(('.f','.for','.f77','.f90')): langs.add('Fortran')
        elif low.endswith(('.p','.pas')): langs.add('Pascal')
    for l in langs: summary[l]+=1
print('libs with DWARF source units by language:',summary)
for lib in sorted(bylib):
    langs=[]
    for x in bylib[lib]:
        low=x.lower()
        if low.endswith(('.f','.for','.f77','.f90','.p','.pas')): langs.append(x)
    if langs: print(lib, langs)
